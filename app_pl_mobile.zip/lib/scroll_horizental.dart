// ignore_for_file: annotate_overrides, non_constant_identifier_names

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:my_app/secondepage.dart';
import 'package:my_app/matches.dart';
import 'package:my_app/choise_page.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Test extends StatefulWidget {
  const Test({
    super.key,
  });

  @override
  State<Test> createState() => _Test();
}

class _Test extends State<Test> {
  int choice = 0;
  var api = 0;
  var m;
  var c;
  getdatafromapi() async {
    String url = "http://localhost:8080/users/get_club";

    http.Response res = await http.get(Uri.parse(url));
    if (res.statusCode == 200) {
      setState(() {
        api = res.statusCode;
        m = res.body;
        m = json.decode(m)['club'];
        for (int i = 0; i < m.length; i++) {
          print(m[i]['name']);
        }
        print(m.length);
      });
    } else {
      setState(() {
        api = res.statusCode;
        print(api);
      });
    }
  }

  getmatches() async {
    String url = "http://localhost:8080/users/get_match";

    http.Response res = await http.get(Uri.parse(url));
    if (res.statusCode == 200) {
      setState(() {
        api = res.statusCode;
        c = res.body;
        c = json.decode(c)['matches'];
        print(c);
      });
    } else {
      setState(() {
        api = res.statusCode;
        print(api);
      });
    }
  }

  Widget build(BuildContext Context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 242, 241, 243),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 20.0),
              height: 200.0,
              child: ListView(
                // This next line does the trick.
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  Container(
                    width: 160.0,
                    color: Colors.red,
                  ),
                  Container(
                    width: 160.0,
                    color: Colors.blue,
                  ),
                  Container(
                    width: 160.0,
                    color: Colors.green,
                  ),
                  Container(
                    width: 160.0,
                    color: Colors.yellow,
                  ),
                  Container(
                    width: 160.0,
                    color: Colors.orange,
                  ),
                ],
              ),
            ),
            TextButton(
                onPressed: () {
                  getmatches();
                },
                child: Text("click")),
            Column(
              children: [
                if (api == 200)
                  for (int i = 0; i < c.length; i++)
                    Row(
                      children: [
                        Image.asset(c[i]['home_image']),
                        Container(
                          child: Text(c[i]['home']),
                        ),
                        Text(c[i]['time']),
                        Container(
                          child: Text(c[i]['away']),
                        ),
                        Image.asset(c[i]['away_image']),
                      ],
                    ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
