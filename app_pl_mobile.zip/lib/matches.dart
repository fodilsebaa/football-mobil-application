// ignore_for_file: prefer_interpolation_to_compose_strings, avoid_unnecessary_containers, prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:my_app/choise_page.dart';
import 'package:cupertino_icons/cupertino_icons.dart' as Cuper;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:my_app/secondepage.dart';
import 'package:percent_indicator/percent_indicator.dart';

class Matches extends StatefulWidget {
  const Matches(
      {super.key,
      required this.clubaway,
      required this.clubawayicon,
      required this.stadium,
      required this.clubhome,
      required this.clubhomeicon,
      required this.week});
  final String stadium;
  final String clubhome;
  final String clubaway;
  final String clubhomeicon;
  final String clubawayicon;
  final String week;

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  State<Matches> createState() => _Matchesstate(this.stadium, this.clubhomeicon,
      this.clubaway, this.clubawayicon, this.clubhome, this.week);
}

class _Matchesstate extends State<Matches> {
  int choice = 0;
  final String stadium;
  final String clubhome;
  final String clubaway;
  final String clubhomeicon;
  final String clubawayicon;
  final String week;
  _Matchesstate(this.stadium, this.clubhomeicon, this.clubaway,
      this.clubawayicon, this.clubhome, this.week);
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 242, 241, 243),
        body: Column(
          children: [
            Container(
                height: MediaQuery.of(context).size.height * 0.95,
                padding: const EdgeInsets.all(5),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        height: 400,
                        child: Stack(children: [
                          Container(
                              width: MediaQuery.of(context).size.width,
                              height: 250,
                              padding: const EdgeInsets.only(
                                  right: 0, left: 5, top: 40),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                image: const DecorationImage(
                                    image: AssetImage(
                                        "images/0821b1ae7739518a83f2ce3741ea1904b862a02c18d205ec8f4967f015767ca3._V_SX1700_.jpg"),
                                    fit: BoxFit.fill),
                              ),
                              child: Container(
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.08,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              color:
                                                  Colors.grey.withOpacity(0.2)),
                                          child: IconButton(
                                            hoverColor: Colors.transparent,
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            icon: const Icon(
                                                FontAwesomeIcons.arrowLeft),
                                            color:
                                                Colors.white.withOpacity(0.6),
                                          ),
                                        ),
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.80,
                                          child: Text(
                                            "Premier League",
                                            style: TextStyle(
                                                color: Colors.white
                                                    .withOpacity(0.9),
                                                fontFamily: 'Roboto-bold',
                                                fontWeight: FontWeight.bold,
                                                fontSize: 25),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.08,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              color:
                                                  Colors.grey.withOpacity(0.2)),
                                          child: IconButton(
                                            hoverColor: Colors.transparent,
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            icon: const Icon(FontAwesomeIcons
                                                .ellipsisVertical),
                                            color:
                                                Colors.white.withOpacity(0.6),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              )),
                          Positioned(
                              bottom: 20,
                              child: Row(
                                children: [
                                  Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.04,
                                    height: 250,
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(top: 20),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15),
                                      color: Colors.white,
                                    ),
                                    width:
                                        MediaQuery.of(context).size.width * 0.9,
                                    height: 250,
                                    child: Column(
                                      children: [
                                        Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          child: Column(
                                            children: [
                                              Text(this.stadium,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: 'Roboto-bold',
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 20)),
                                              Text(
                                                "Week " + this.week,
                                                style: TextStyle(
                                                    color: Colors.black
                                                        .withOpacity(0.4)),
                                              )
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(top: 20),
                                          child: Row(
                                            children: [
                                              Container(
                                                alignment: Alignment.center,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.30,
                                                child: Column(
                                                  children: [
                                                    Image.asset(
                                                      this.clubhomeicon,
                                                      width: 100,
                                                      height: 100,
                                                    ),
                                                    Text(
                                                      this.clubhome,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontFamily:
                                                              'Roboto-bold',
                                                          fontSize: 15),
                                                    ),
                                                    Text(
                                                      "Home",
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontFamily:
                                                              'Roboto-bold',
                                                          color: Colors.black
                                                              .withOpacity(
                                                                  0.4)),
                                                    )
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                alignment: Alignment.center,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.30,
                                                child: Column(
                                                  children: [
                                                    Text(
                                                      "3 : 0",
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontFamily:
                                                              'Roboto-bold',
                                                          fontSize: 40),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.only(
                                                          top: 5),
                                                      padding:
                                                          EdgeInsets.all(10),
                                                      child: Text(
                                                        "83'",
                                                        style: TextStyle(
                                                            color: const Color
                                                                    .fromARGB(
                                                                234,
                                                                249,
                                                                21,
                                                                123),
                                                            fontFamily:
                                                                'Roboto-bold',
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                      decoration: BoxDecoration(
                                                        color: const Color
                                                                    .fromARGB(
                                                                234,
                                                                249,
                                                                21,
                                                                123)
                                                            .withOpacity(0.2),
                                                        border: Border.all(
                                                            color: const Color
                                                                        .fromARGB(
                                                                    234,
                                                                    249,
                                                                    21,
                                                                    123)
                                                                .withOpacity(
                                                                    0.8),
                                                            width: 2),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                alignment: Alignment.center,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.30,
                                                child: Column(
                                                  children: [
                                                    Image.asset(
                                                      this.clubawayicon,
                                                      width: 100,
                                                      height: 100,
                                                    ),
                                                    Text(
                                                      this.clubaway,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontFamily:
                                                              'Roboto-bold',
                                                          fontSize: 15),
                                                    ),
                                                    Text(
                                                      "Away",
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontFamily:
                                                              'Roboto-bold',
                                                          color: Colors.black
                                                              .withOpacity(
                                                                  0.4)),
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ))
                        ]),
                      ),
                      Row(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.04,
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.9,
                            padding: EdgeInsets.only(top: 10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  alignment: Alignment.center,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      InkWell(
                                        hoverColor: Colors.transparent,
                                        onTap: () {
                                          setState(() {
                                            choice = 0;
                                          });
                                        },
                                        child: Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.25,
                                            alignment: Alignment.center,
                                            margin: const EdgeInsets.only(
                                                right: 20),
                                            padding: const EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                              color: choice == 0
                                                  ? Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  : Colors.grey
                                                      .withOpacity(0.2),
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.2),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: const Offset(0,
                                                      3), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Text(
                                              "Stats",
                                              style: TextStyle(
                                                  fontFamily: "Roboto-bold",
                                                  fontSize: 15,
                                                  color: choice == 0
                                                      ? Colors.white
                                                          .withOpacity(0.8)
                                                      : Colors.grey
                                                          .withOpacity(0.8)),
                                            )),
                                      ),
                                      InkWell(
                                        hoverColor: Colors.transparent,
                                        onTap: () {
                                          setState(() {
                                            choice = 1;
                                          });
                                        },
                                        child: Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.25,
                                            alignment: Alignment.center,
                                            margin: const EdgeInsets.only(
                                                right: 20),
                                            padding: const EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                              color: choice == 1
                                                  ? const Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  : Colors.grey
                                                      .withOpacity(0.2),
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.2),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: const Offset(0,
                                                      3), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Text(
                                              "Line-up",
                                              style: TextStyle(
                                                  fontFamily: "Roboto-bold",
                                                  fontSize: 15,
                                                  color: choice == 1
                                                      ? Colors.white
                                                          .withOpacity(0.8)
                                                      : Colors.grey
                                                          .withOpacity(0.8)),
                                            )),
                                      ),
                                      InkWell(
                                        hoverColor: Colors.transparent,
                                        onTap: () {
                                          setState(() {
                                            choice = 2;
                                          });
                                        },
                                        child: Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.25,
                                            alignment: Alignment.center,
                                            padding: const EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                              color: choice == 2
                                                  ? const Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  : Colors.grey
                                                      .withOpacity(0.2),
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.2),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: const Offset(0,
                                                      3), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Text(
                                              "Summary",
                                              style: TextStyle(
                                                  fontFamily: "Roboto-bold",
                                                  fontSize: 15,
                                                  color: choice == 2
                                                      ? Colors.white
                                                          .withOpacity(0.8)
                                                      : Colors.grey
                                                          .withOpacity(0.8)),
                                            )),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "2",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Shots On Goal",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "6",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.25,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.75,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "4",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Shots",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "15",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.21,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.79,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "26%",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Possession%",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "74%",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.26,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.74,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "3",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Yellow Card",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "2",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.6,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.4,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "0",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Corners Knicks",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "2",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 1,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "10",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Crosses",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "23",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.3,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.7,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Text(
                                          "3",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                      Container(
                                        child: Text(
                                          "Goalkeepers Saves",
                                          style: TextStyle(
                                              fontFamily: "Roboto-bold",
                                              fontSize: 15,
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      Container(
                                        child: Text(
                                          "2",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                      234, 249, 21, 123)
                                                  .withOpacity(0.8),
                                              fontFamily: "Roboto-bold",
                                              fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.07,
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.6,
                                        progressColor: const Color.fromARGB(
                                                234, 249, 21, 123)
                                            .withOpacity(0.8),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 10),
                                      child: LinearPercentIndicator(
                                        barRadius: Radius.circular(15),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.425,
                                        lineHeight: 8.0,
                                        percent: 0.4,
                                        progressColor:
                                            Color.fromARGB(255, 59, 0, 61)
                                                .withOpacity(0.8),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                )),
            /* Container(
              height: MediaQuery.of(context).size.height * 0.13,
              decoration: BoxDecoration(
                color: Colors.white,
                /* boxShadow: [
                BoxShadow(
                  color: Colors.transparent.withOpacity(0.8),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ], */
              ),
              padding: EdgeInsets.only(top: 10),
              margin: EdgeInsets.only(top: 10),
              child: Row(
                children: [
                  Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.25,
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          IconButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return const Choicepage(payment_method: 'Home');
                              }));
                            },
                            icon: Icon(
                              FontAwesomeIcons.house,
                              color: Color.fromARGB(255, 83, 113, 136),
                            ),
                          ),
                        ],
                      )),
                  Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.25,
                      alignment: Alignment.center,
                      child: IconButton(
                        onPressed: () {},
                        icon: Icon(
                          FontAwesomeIcons.calendarDays,
                          color: Colors.black.withOpacity(0.3),
                        ),
                      )),
                  Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.25,
                      alignment: Alignment.center,
                      child: IconButton(
                        onPressed: () {},
                        icon: Icon(
                          FontAwesomeIcons.squarePollVertical,
                          color: Colors.black.withOpacity(0.3),
                        ),
                      )),
                  Container(
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.25,
                      alignment: Alignment.center,
                      child: IconButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (BuildContext context) {
                              return Secondepage(
                                title: 'Home',
                                name: "name",
                                familyname: "familyname",
                              );
                            }),
                          );
                        },
                        icon: Icon(
                          FontAwesomeIcons.user,
                          color: Colors.black.withOpacity(0.3),
                        ),
                      ))
                ],
              ),
            ) */
          ],
        ));
  }
}
