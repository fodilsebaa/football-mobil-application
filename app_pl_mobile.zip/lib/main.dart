// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_interpolation_to_compose_strings

import 'package:flutter/material.dart';
import 'package:my_app/secondepage.dart';
import 'package:http/http.dart' as http;
import 'package:my_app/signup.dart';

void main() {
  runApp(const Login());
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => MyApp();
}

class MyApp extends State<Login> {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.
          primarySwatch: Colors.indigo),
      home: const MyHomePage(title: 'My First Flutter application'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int counter = 0;
  int current_page = 0;
  String enteredText = "";
  String message_validation = "";
  String name = "";
  String familyname = "";
  int api = 0;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController familynamecontroller =
      new TextEditingController();
  void increment() {
    setState(() {
      counter++;
    });
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    nameController.dispose();
    familynamecontroller.dispose();
    super.dispose();
  }

  void decrement() {
    setState(() {
      counter = 0;
    });
  }

  getdatafromapi() async {
    String url = "http://localhost:8080/users/login?password=" +
        familynamecontroller.text +
        "&email=" +
        nameController.text;
    http.Response res = await http.post(Uri.parse(url));
    if (res.statusCode == 200) {
      setState(() {
        api = res.statusCode;
      });
    } else {
      setState(() {
        api = res.statusCode;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /* appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        leading:,
      ), */
      body: SingleChildScrollView(
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Invoke "debug painting" (press "p" in the console, choose the
          // "Toggle Debug Paint" action from the Flutter Inspector in Android
          // Studio, or the "Toggle Debug Paint" command in Visual Studio Code)
          // to see the wireframe for each widget.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).

          /* mainAxisAlignment: MainAxisAlignment.center, */

          children: <Widget>[
            Title(
                color: Colors.black,
                child: Container(
                    /* color: Colors.indigo,
                  height: 300, */

                    child: /* Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "SIGN-IN",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ],
                  ), */
                        Stack(
                  children: [
                    Opacity(
                      opacity: 0.5,
                      child: ClipPath(
                        clipper: WaveClipper(),
                        child: Container(
                          decoration: const BoxDecoration(
                              gradient: LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [
                              Color.fromARGB(255, 59, 0, 61),
                              Color.fromARGB(255, 234, 76, 137),
                            ],
                          )),
                          height: 600,
                        ),
                      ),
                    ),
                    ClipPath(
                      clipper: WaveClipper(),
                      child: Container(
                        /* color: Color.fromARGB(255, 147, 112, 219), */
                        height: 580,
                        padding: const EdgeInsets.only(top: 80),
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: [
                            Color.fromARGB(255, 59, 0, 61),
                            Color.fromARGB(255, 234, 76, 137),
                          ],
                        )),
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(bottom: 10),
                              child: const Text(
                                "Login",
                                style: TextStyle(
                                    fontSize: 50,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Roboto-bold'),
                              ),
                            ),
                            if (api == 400)
                              Text(
                                message_validation,
                                style: const TextStyle(
                                    color: Colors.red,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Roboto-bold'),
                              ),
                            Container(
                              margin: const EdgeInsets.only(
                                  right: 50, left: 50, top: 20, bottom: 20),
                              child: TextField(
                                  style: const TextStyle(fontFamily: 'Roboto'),
                                  textAlign: TextAlign.center,
                                  controller: nameController,
                                  decoration: InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      hintText: 'email',
                                      prefixIcon: const Visibility(
                                        visible: true,
                                        child: Icon(
                                          Icons.email,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(20.0)),
                                      // ignore: prefer_const_constructors
                                      hintStyle: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'Roboto'))),
                            ),
                            Container(
                              margin: const EdgeInsets.only(
                                  right: 50, left: 50, top: 20, bottom: 40),
                              child: TextField(
                                style: const TextStyle(fontFamily: 'Roboto'),
                                textAlign: TextAlign.center,
                                controller: familynamecontroller,
                                decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Password',
                                    prefixIcon: const Visibility(
                                      visible: true,
                                      child: Icon(
                                        Icons.lock,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(20.0)),
                                    // ignore: prefer_const_constructors
                                    hintStyle: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Roboto',
                                    )),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(
                                      right: 20, left: 20, top: 20, bottom: 20),
                                  child: SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width - 100,
                                    height: 50,
                                    child: FilledButton(
                                        onPressed: () async {
                                          setState(() {
                                            api = 10;
                                          });
                                          await getdatafromapi();
                                          print(api);
                                          setState(() {
                                            if (api == 200) {
                                              message_validation = "";
                                            } else {
                                              message_validation =
                                                  "Wrong email or password!";
                                            }
                                            if (api == 200) {
                                              Navigator.of(context).push(
                                                MaterialPageRoute(builder:
                                                    (BuildContext context) {
                                                  return Secondepage(
                                                    title: 'Home',
                                                    name: name,
                                                    familyname: familyname,
                                                  );
                                                }),
                                              );
                                            }
                                          });
                                        },
                                        style: FilledButton.styleFrom(
                                            backgroundColor:
                                                Color.fromARGB(255, 59, 0, 61)
                                                    .withOpacity(0.8)),
                                        child: const Text(
                                          "Login",
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontFamily: 'Roboto'),
                                        )),
                                  ),
                                ),
                                /*  const SizedBox(
                                  width: 20,
                                ), */
                                /* FilledButton(
                                    onPressed: () {
                                      setState(() {
                                        name = nameController.text;
                                        familyname = familynamecontroller.text;
                                        if (nameController.text != "" &&
                                            familynamecontroller.text != "") {
                                          message_validation =
                                              "saha ramdanek " +
                                                  nameController.text +
                                                  " " +
                                                  familynamecontroller.text;
                                        }
                                        if (nameController.text == "" &&
                                            familynamecontroller.text == "") {
                                          message_validation = "";
                                        }
                                      });
                                    },
                                    child: const Text("Sign-Up")), */
                              ],
                            ),
                            const Text(
                              "forgot your password?",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Roboto',
                                  fontSize: 20),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ))),
            /* Text(
              message_validation,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ), */
            if (api == 10)
              const CircularProgressIndicator(
                color: Color.fromARGB(255, 59, 0, 61),
              ),
            Container(
                margin: const EdgeInsets.only(
                    top: 40, bottom: 20, left: 20, right: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Does have Account?  ",
                      style: TextStyle(
                        fontFamily: 'Roboto-bold',
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (BuildContext context) {
                              return Signup();
                            }),
                          );
                        },
                        child: const Text(
                          "Sign up",
                          style: TextStyle(
                            fontFamily: 'Roboto-bold',
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 59, 0, 61),
                          ),
                        ))
                  ],
                )),
            /* Container(
              margin: const EdgeInsets.only(
                  left: 20.0, right: 20.0, top: 20.0, bottom: 80.0),
              child: TextField(
                controller: familynamecontroller,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'FamilyName',
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.all(20.0),
              child: const Text(
                'You have pushed the button this many times:',
              ),
            ),
            Text(
              '$counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ), */
          ],
        ),
      ),

      /* bottomNavigationBar: NavigationBar(
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home), label: "Home"),
          const NavigationDestination(
              icon: Icon(Icons.access_time), label: "Historique"),
        ],
        onDestinationSelected: (int index) {
          setState(() {
            current_page = index;
            if (index == 1) {
              name = nameController.text;
              familyname = familynamecontroller.text;
              Navigator.of(context).push(
                MaterialPageRoute(builder: (BuildContext context) {
                  return Secondepage(
                    title: 'Home',
                    name: name,
                    familyname: familyname,
                  );
                }),
              );
            }
          });
        },
        selectedIndex: current_page,
      ), */
      /* floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          IconButton(
              onPressed: () {
                increment();
              },
              icon: const Icon(Icons.plus_one)),
          const SizedBox(
            width: 20,
          ),
          IconButton(
              onPressed: () {
                decrement();
              },
              icon: const Icon(Icons.reset_tv)),
        ],
      ), */
    );
  }
}

class WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    debugPrint(size.width.toString());
    var path = new Path();
    path.lineTo(0, size.height);
    var firstStart = Offset(size.width / 5, size.height);
    var firstEnd = Offset(size.width / 2.25, size.height - 50.0);
    path.quadraticBezierTo(
        firstStart.dx, firstStart.dy, firstEnd.dx, firstEnd.dy);
    var secondStart =
        Offset(size.width - (size.width / 3.24), size.height - 105);
    var secondEnd = Offset(size.width, size.height - 10);
    path.quadraticBezierTo(
        secondStart.dx, secondStart.dy, secondEnd.dx, secondEnd.dy);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return true;
  }
}
/* class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Invoke "debug painting" (press "p" in the console, choose the
          // "Toggle Debug Paint" action from the Flutter Inspector in Android
          // Studio, or the "Toggle Debug Paint" command in Visual Studio Code)
          // to see the wireframe for each widget.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
} */
