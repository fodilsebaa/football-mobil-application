// ignore_for_file: annotate_overrides, non_constant_identifier_names

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:my_app/secondepage.dart';
import 'package:my_app/matches.dart';
import 'package:my_app/home_pl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Choicepage extends StatefulWidget {
  const Choicepage({
    super.key,
    required this.payment_method,
  });

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String payment_method;
  @override
  State<Choicepage> createState() => _Choicepagestate();
}

class _Choicepagestate extends State<Choicepage> {
  int choice = 0;
  var api = 0;
  var m;
  var c;
  getdatafromapi() async {
    String url = "http://localhost:8080/users/get_club";

    http.Response res = await http.get(Uri.parse(url));
    if (res.statusCode == 200) {
      setState(() {
        api = res.statusCode;
        m = res.body;
        m = json.decode(m)['club'];
        for (int i = 0; i < m.length; i++) {
          print(m[i]['name']);
        }
        print(m.length);
      });
    } else {
      setState(() {
        api = res.statusCode;
        print(api);
      });
    }
  }

  getmatches() async {
    String url = "http://localhost:8080/users/get_match";

    http.Response res = await http.get(Uri.parse(url));
    if (res.statusCode == 200) {
      setState(() {
        api = res.statusCode;
        c = res.body;
        c = json.decode(c)['matches'];
        print(c);
      });
    } else {
      setState(() {
        api = res.statusCode;
        print(api);
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getmatches();
  }

  Widget build(BuildContext Context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 242, 241, 243),
      body: Column(
        children: [
          Container(
              height: MediaQuery.of(context).size.height * 0.85,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 40,
                          margin: const EdgeInsets.only(top: 30, left: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: IconButton(
                            hoverColor: Colors.transparent,
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: const Icon(FontAwesomeIcons.arrowLeft),
                            color: Colors.black.withOpacity(0.6),
                          ),
                        ),
                        Container(
                            width: MediaQuery.of(context).size.width - 120,
                            padding: const EdgeInsets.only(top: 30),
                            alignment: Alignment.center,
                            decoration: const BoxDecoration(),
                            child: const Text(
                              "Matchs",
                              style: TextStyle(
                                  fontSize: 30,
                                  fontFamily: 'Roboto-bold',
                                  fontWeight: FontWeight.bold),
                            )),
                        Container(
                          width: 40,
                          margin: EdgeInsets.only(top: 30, right: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: IconButton(
                            hoverColor: Colors.transparent,
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: const Icon(FontAwesomeIcons.magnifyingGlass),
                            color: Colors.black.withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 30, left: 20),
                      child: Row(
                        children: [
                          InkWell(
                            hoverColor: Colors.transparent,
                            onTap: () {
                              setState(() {
                                choice = 0;
                              });
                            },
                            child: Container(
                                margin: const EdgeInsets.only(right: 20),
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: choice == 0
                                      ? const Color.fromARGB(234, 249, 21, 123)
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.2),
                                      spreadRadius: 5,
                                      blurRadius: 7,
                                      offset: const Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    Image.asset(choice == 0
                                        ? "images/premier-league-white.png"
                                        : "images/output-onlinepngtools.png"),
                                    Text(
                                      " Premier League",
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: choice == 0
                                              ? Colors.white
                                              : Colors.grey,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Roboto-bold'),
                                    ),
                                  ],
                                )),
                          ),
                          /* InkWell(
                            hoverColor: Colors.transparent,
                            onTap: () {
                              setState(() {
                                choice = 1;
                              });
                            },
                            child: Container(
                                margin: const EdgeInsets.only(right: 20),
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: choice == 0
                                      ? Colors.white
                                      : const Color.fromARGB(255, 83, 113, 136),
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.2),
                                      spreadRadius: 5,
                                      blurRadius: 7,
                                      offset: const Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    Image.asset(
                                      choice == 0
                                          ? "images/ligapng.png"
                                          : "images/output-onlinepngtoolsliga.png",
                                      width: 30,
                                      height: 25,
                                    ),
                                    Text(
                                      " La Liga",
                                      style: TextStyle(
                                          fontSize: 15,
                                          color: choice == 0
                                              ? Colors.grey
                                              : Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Roboto-bold'),
                                    ),
                                  ],
                                )),
                          ), */
                          /* Container(
                        margin: const EdgeInsets.only(right: 20),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            Image.asset(
                              "images/download.png",
                              width: 35,
                              height: 25,
                            ),
                            const Text(
                              " Serie A",
                              style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Roboto-bold'),
                            ),
                          ],
                        )), */
                        ],
                      ),
                    ),
                    if (choice == 0)
                      Column(children: [
                        if (api == 200)
                          for (int i = 0; i < c.length; i++)
                            InkWell(
                              hoverColor: Colors.transparent,
                              onTap: () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return Matches(
                                    clubhome: c[i]['home'],
                                    clubaway: c[i]['away'],
                                    stadium: c[i]['stadium'],
                                    clubhomeicon: c[i]['home_image'],
                                    clubawayicon: c[i]['away_image'],
                                    week: c[i]['journe'],
                                  );
                                }));
                              },
                              child: Container(
                                margin: const EdgeInsets.only(top: 20),
                                padding:
                                    const EdgeInsets.only(top: 20, bottom: 20),
                                width: MediaQuery.of(context).size.width - 40,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.38,
                                        decoration: const BoxDecoration(),
                                        alignment: Alignment.centerRight,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Text(
                                              c[i]['home'],
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Roboto-bold',
                                                fontSize: 12,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            Image.asset(
                                              c[i]['home_image'],
                                              width: 30,
                                              height: 30,
                                            )
                                          ],
                                        )),
                                    Container(
                                        margin: const EdgeInsets.only(right: 0),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.2,
                                        decoration: const BoxDecoration(),
                                        child: Column(
                                          children: [
                                            Text(
                                              c[i]['time'],
                                              style: TextStyle(
                                                  color: Color.fromARGB(
                                                      255, 232, 143, 105),
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              c[i]['date'],
                                              style: TextStyle(
                                                  color: Colors.black
                                                      .withOpacity(0.4)),
                                            ),
                                          ],
                                        )),
                                    Container(
                                        alignment: Alignment.centerRight,
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.32,
                                        decoration: BoxDecoration(),
                                        child: Row(
                                          children: [
                                            Image.asset(
                                              c[i]['away_image'],
                                              width: 30,
                                              height: 30,
                                            ),
                                            Text(
                                              c[i]['away'],
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Roboto-bold',
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                            ),
                        /* InkWell(
                          hoverColor: Colors.transparent,
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const Matches(
                                clubhome: "Afc Bournemouth",
                                clubaway: "Arsenal Fc",
                                stadium: "Bournemouth Stadium",
                                clubhomeicon:
                                    'images/580b57fcd9996e24bc43c4de.png',
                                clubawayicon:
                                    'images/580b57fcd9996e24bc43c4df.png',
                              );
                            }));
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 20),
                            padding: const EdgeInsets.only(top: 20, bottom: 20),
                            width: MediaQuery.of(context).size.width - 35,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Row(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.38,
                                    decoration: const BoxDecoration(),
                                    alignment: Alignment.centerRight,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        const Text(
                                          "Afc Bournemouth ",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4de.png',
                                          width: 30,
                                          height: 30,
                                        )
                                      ],
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(right: 0),
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                    decoration: const BoxDecoration(),
                                    child: Column(
                                      children: [
                                        Text(
                                          "18:30",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 232, 143, 105),
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          "30 OCT",
                                          style: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.4)),
                                        ),
                                      ],
                                    )),
                                Container(
                                    alignment: Alignment.centerRight,
                                    width: MediaQuery.of(context).size.width *
                                        0.32,
                                    decoration: BoxDecoration(),
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4df.png',
                                          width: 30,
                                          height: 30,
                                        ),
                                        const Text(
                                          " Arsenal Fc",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ))
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          hoverColor: Colors.transparent,
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const Matches(
                                clubhome: "Everton Fc",
                                clubaway: "Manchester Utd",
                                stadium: "Everton Stadium",
                                clubhomeicon:
                                    'images/580b57fcd9996e24bc43c4e3.png',
                                clubawayicon:
                                    'images/580b57fcd9996e24bc43c4e7.png',
                              );
                            }));
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 20),
                            padding: const EdgeInsets.only(top: 20, bottom: 20),
                            width: MediaQuery.of(context).size.width - 40,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Row(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.38,
                                    decoration: const BoxDecoration(),
                                    alignment: Alignment.centerRight,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        const Text(
                                          "Everton Fc ",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4e3.png',
                                          width: 30,
                                          height: 30,
                                        )
                                      ],
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(right: 0),
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                    decoration: const BoxDecoration(),
                                    child: Column(
                                      children: [
                                        Text(
                                          "20:30",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 232, 143, 105),
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          "30 OCT",
                                          style: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.4)),
                                        ),
                                      ],
                                    )),
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.32,
                                    decoration: BoxDecoration(),
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4e7.png',
                                          width: 30,
                                          height: 30,
                                        ),
                                        const Text(
                                          " Manchester Utd",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ))
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          hoverColor: Colors.transparent,
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const Matches(
                                clubhome: "Leicester City",
                                clubaway: "Newcastle Utd",
                                stadium: "King Power Stadium",
                                clubhomeicon:
                                    'images/580b57fcd9996e24bc43c4e8.png',
                                clubawayicon:
                                    'images/580b57fcd9996e24bc43c4ec.png',
                              );
                            }));
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 20),
                            padding: const EdgeInsets.only(top: 20, bottom: 20),
                            width: MediaQuery.of(context).size.width - 40,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Row(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.38,
                                    decoration: const BoxDecoration(),
                                    alignment: Alignment.centerRight,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        const Text(
                                          "Leicester City ",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4e8.png',
                                          width: 30,
                                          height: 30,
                                        )
                                      ],
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(right: 0),
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                    decoration: const BoxDecoration(),
                                    child: Column(
                                      children: [
                                        Text(
                                          "20:30",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 232, 143, 105),
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          "30 OCT",
                                          style: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.4)),
                                        ),
                                      ],
                                    )),
                                Container(
                                    alignment: Alignment.centerRight,
                                    width: MediaQuery.of(context).size.width *
                                        0.32,
                                    decoration: BoxDecoration(),
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4ec.png',
                                          width: 30,
                                          height: 30,
                                        ),
                                        const Text(
                                          " Newcastle Utd",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ))
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          hoverColor: Colors.transparent,
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const Matches(
                                clubhome: "Tottenham",
                                clubaway: "West Ham",
                                stadium: "Tottenham Stadium",
                                clubhomeicon:
                                    'images/580b57fcd9996e24bc43c4ee.png',
                                clubawayicon:
                                    'images/580b57fcd9996e24bc43c4f1.png',
                              );
                            }));
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 20),
                            padding: const EdgeInsets.only(top: 20, bottom: 20),
                            width: MediaQuery.of(context).size.width - 40,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Row(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.38,
                                    decoration: const BoxDecoration(),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        const Text(
                                          "Tottenham ",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4ee.png',
                                          width: 30,
                                          height: 30,
                                        )
                                      ],
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(right: 0),
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                    decoration: const BoxDecoration(),
                                    child: Column(
                                      children: [
                                        Text(
                                          "20:30",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 232, 143, 105),
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          "30 OCT",
                                          style: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.4)),
                                        ),
                                      ],
                                    )),
                                Container(
                                    alignment: Alignment.centerRight,
                                    width: MediaQuery.of(context).size.width *
                                        0.32,
                                    decoration: BoxDecoration(),
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4f1.png',
                                          width: 30,
                                          height: 30,
                                        ),
                                        const Text(
                                          " West Ham",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ))
                              ],
                            ),
                          ),
                        ),
                        InkWell(
                          hoverColor: Colors.transparent,
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const Matches(
                                clubhome: "Aston Vila",
                                clubaway: "Chelsea Fc",
                                stadium: "Aston Vila Stadium",
                                clubhomeicon:
                                    'images/580b57fcd9996e24bc43c4e4.png',
                                clubawayicon: 'images/chelsea-fc-2.png',
                              );
                            }));
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 20),
                            padding: const EdgeInsets.only(top: 20, bottom: 20),
                            width: MediaQuery.of(context).size.width - 40,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Row(
                              children: [
                                Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.38,
                                    decoration: const BoxDecoration(),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        const Text(
                                          "Aston Vila ",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                        Image.asset(
                                          'images/580b57fcd9996e24bc43c4e4.png',
                                          width: 30,
                                          height: 30,
                                        )
                                      ],
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(right: 0),
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                    decoration: const BoxDecoration(),
                                    child: Column(
                                      children: [
                                        Text(
                                          "20:30",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 232, 143, 105),
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          "30 OCT",
                                          style: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.4)),
                                        ),
                                      ],
                                    )),
                                Container(
                                    alignment: Alignment.centerRight,
                                    width: MediaQuery.of(context).size.width *
                                        0.32,
                                    decoration: BoxDecoration(),
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          'images/chelsea-fc-2.png',
                                          width: 30,
                                          height: 30,
                                        ),
                                        const Text(
                                          " Chelsea Fc",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Roboto-bold',
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ))
                              ],
                            ),
                          ),
                        ), */
                      ]),
                  ],
                ),
              )),
          Container(
            height: MediaQuery.of(context).size.height * 0.13,
            decoration: BoxDecoration(
              color: Colors.white,
              /* boxShadow: [
                BoxShadow(
                  color: Colors.transparent.withOpacity(0.8),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ], */
            ),
            padding: EdgeInsets.only(top: 10),
            margin: EdgeInsets.only(top: 10),
            child: Row(
              children: [
                Container(
                  height: 50,
                  width: MediaQuery.of(context).size.width * 0.25,
                  alignment: Alignment.center,
                  child: IconButton(
                    onPressed: () {
                      /* Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const Choicepage(payment_method: 'Home');
                            })); */
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (BuildContext context) {
                          return PLhome();
                        }),
                      );
                    },
                    icon: Icon(
                      FontAwesomeIcons.house,
                      color: Colors.black.withOpacity(0.3),
                    ),
                  ),
                ),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {},
                      icon: Icon(
                        FontAwesomeIcons.calendarDays,
                        color: choice == 0
                            ? const Color.fromARGB(234, 249, 21, 123)
                            : const Color.fromARGB(255, 83, 113, 136),
                      ),
                    )),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {},
                      icon: Icon(
                        FontAwesomeIcons.squarePollVertical,
                        color: Colors.black.withOpacity(0.3),
                      ),
                    )),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (BuildContext context) {
                            return Secondepage(
                              title: 'Home',
                              name: "name",
                              familyname: "familyname",
                            );
                          }),
                        );
                      },
                      icon: Icon(
                        FontAwesomeIcons.user,
                        color: Colors.black.withOpacity(0.3),
                      ),
                    ))
              ],
            ),
          )
        ],
      ),
    );
  }
}
