// ignore_for_file: prefer_interpolation_to_compose_strings, avoid_unnecessary_containers, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:my_app/choise_page.dart';
import 'package:cupertino_icons/cupertino_icons.dart' as Cuper;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:my_app/home_pl.dart';

class Secondepage extends StatefulWidget {
  const Secondepage(
      {super.key,
      required this.title,
      required this.name,
      required this.familyname});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;
  final String name;
  final String familyname;

  @override
  State<Secondepage> createState() => _Secondepagestate();
}

class _Secondepagestate extends State<Secondepage> {
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      child: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            padding: const EdgeInsets.only(top: 8.0, left: 8.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  /* Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          icon: const Icon(Icons.arrow_back),
                          color: Color.fromARGB(255, 59, 0, 61),
                        ),
                      ],
                    ), */
                  Row(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 30),
                        child: const Text(
                          "Start your ",
                          style: TextStyle(
                              fontSize: 20,
                              fontFamily: 'Roboto-bold',
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(
                          top: 30,
                        ),
                        child: const Text(
                          "free ",
                          style: TextStyle(
                              fontSize: 20,
                              color: Color.fromARGB(255, 59, 0, 61),
                              fontFamily: 'Roboto-bold',
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(
                          top: 30,
                        ),
                        child: const Text(
                          "7 days",
                          style: TextStyle(
                              fontSize: 20,
                              fontFamily: 'Roboto-bold',
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  Container(
                      child: Row(
                    children: const [
                      Text(
                        "Get complete,unlimited access to all",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ],
                  )),
                  Container(
                    margin: const EdgeInsets.only(bottom: 30),
                    child: Row(
                      children: const [
                        Text(
                          "Skillshare classes.",
                          style: TextStyle(
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(bottom: 20),
                    child: Row(
                      children: const [
                        Text("Pick a plan",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Roboto-bold',
                            )),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      Center(
                        child: Container(
                            width: MediaQuery.of(context).size.width - 20,
                            decoration: BoxDecoration(
                              border: Border.all(
                                  color: Color.fromARGB(255, 59, 0, 61),
                                  width: 2),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.2),
                                  spreadRadius: 5,
                                  blurRadius: 7,
                                  offset: const Offset(
                                      0, 3), // changes position of shadow
                                ),
                              ],
                            ),
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 15.0, bottom: 15),
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.5,
                                child: Row(
                                  children: [
                                    Container(
                                      child: Column(
                                        children: [
                                          Row(
                                            children: const [
                                              Text(
                                                "Starter",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 20,
                                                  fontFamily: 'Roboto-bold',
                                                ),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            children: const [
                                              Text(
                                                "US 120.00/billed annualy",
                                                style: TextStyle(
                                                  fontFamily: 'Roboto-bold',
                                                ),
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    ),
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.2,
                                    ),
                                    Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.3,
                                        alignment: Alignment.centerRight,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            const Text(
                                              "US 10.25/mo",
                                              style: TextStyle(
                                                color: Color.fromARGB(
                                                    255, 59, 0, 61),
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Roboto-bold',
                                              ),
                                            ),
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                            )),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Container(
                          margin: const EdgeInsets.only(top: 20),
                          width: MediaQuery.of(context).size.width - 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: const Offset(
                                    0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding:
                                const EdgeInsets.only(top: 15.0, bottom: 15),
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: Row(
                                children: [
                                  Column(
                                    children: [
                                      Row(
                                        children: const [
                                          Text(
                                            "Premium",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20,
                                              fontFamily: 'Roboto-bold',
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: const [
                                          Text(
                                            "US 120.00/billed annualy",
                                            style: TextStyle(
                                              fontFamily: 'Roboto-bold',
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                  ),
                                  Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.3,
                                      alignment: Alignment.centerRight,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          const Text(
                                            "US 10.25/mo",
                                            style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 59, 0, 61),
                                              fontWeight: FontWeight.bold,
                                              fontFamily: 'Roboto-bold',
                                            ),
                                          ),
                                        ],
                                      ))
                                ],
                              ),
                            ),
                          )),
                    ],
                  ),
                  Row(
                    children: [
                      Container(
                          margin: const EdgeInsets.only(top: 20),
                          width: MediaQuery.of(context).size.width - 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: const Offset(
                                    0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding:
                                const EdgeInsets.only(top: 15.0, bottom: 15),
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: Row(
                                children: [
                                  Column(
                                    children: [
                                      Row(
                                        children: const [
                                          Text(
                                            "Advance",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20,
                                              fontFamily: 'Roboto-bold',
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: const [
                                          Text(
                                            "US 120.00/billed annualy",
                                            style: TextStyle(
                                              fontFamily: 'Roboto-bold',
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width * 0.2,
                                  ),
                                  Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.3,
                                      alignment: Alignment.centerRight,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          const Text(
                                            "US 10.25/mo",
                                            style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 59, 0, 61),
                                              fontWeight: FontWeight.bold,
                                              fontFamily: 'Roboto-bold',
                                            ),
                                          ),
                                        ],
                                      ))
                                ],
                              ),
                            ),
                          )),
                    ],
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width - 20,
                    child: Row(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.75,
                          margin: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Row(
                            children: [
                              const Text(
                                "Payment Method",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  fontFamily: 'Roboto-bold',
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Row(
                            children: [
                              const Text(
                                "Add New",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontFamily: 'Roboto-bold',
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width - 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: const Offset(
                                    0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Row(
                              children: [
                                Column(
                                  children: [
                                    Container(
                                      width: 50,
                                      child: Image.asset(
                                          'images/Mastercard-logo.svg.png'),
                                    )
                                  ],
                                ),
                                Container(
                                    margin: const EdgeInsets.only(left: 20),
                                    child: const Text(
                                      "Mastercard",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Roboto-bold',
                                      ),
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(left: 20),
                                    child: const Text(
                                      "0 1",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Roboto-bold',
                                      ),
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(left: 20),
                                    child: const Text(
                                      ".....145",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Roboto-bold',
                                      ),
                                    )),
                                Container(
                                    margin: const EdgeInsets.only(left: 40),
                                    child: const Icon(Icons.arrow_drop_down))
                              ],
                            ),
                          )),
                    ],
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    child: FilledButton(
                      onPressed: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (BuildContext context) {
                          return const Choicepage(payment_method: 'Home');
                        }));
                      },
                      style: FilledButton.styleFrom(
                          backgroundColor: Color.fromARGB(255, 59, 0, 61)),
                      child: const Text(
                        "START YOUR FREE 7 DAYS",
                        style: TextStyle(
                            fontFamily: 'Roboto-bold',
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: OutlinedButton(
                        onPressed: () {},
                        child: Row(
                          children: [
                            const Text(
                              "Skip& ",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontFamily: 'Roboto-bold',
                                  fontWeight: FontWeight.bold),
                            ),
                            const Text(
                              "Will Pay By Gurdian",
                              style: TextStyle(
                                  color: Color.fromARGB(255, 59, 0, 61),
                                  fontFamily: 'Roboto-bold',
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      )),
                ],
              ),
            ),
          ),
          Container(
            height: MediaQuery.of(context).size.height * 0.135,
            decoration: const BoxDecoration(
              color: Colors.white,
              /* boxShadow: [
                BoxShadow(
                  color: Colors.transparent.withOpacity(0.8),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ], */
            ),
            padding: EdgeInsets.only(top: 10),
            margin: EdgeInsets.only(top: 10),
            child: Row(
              children: [
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (BuildContext context) {
                          return const PLhome();
                        }));
                      },
                      icon: Icon(
                        FontAwesomeIcons.house,
                        color: Colors.black.withOpacity(0.3),
                      ),
                    )),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (BuildContext context) {
                          return const Choicepage(payment_method: 'Home');
                        }));
                      },
                      icon: Icon(
                        FontAwesomeIcons.calendarDays,
                        color: Colors.black.withOpacity(0.3),
                      ),
                    )),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {},
                      icon: Icon(
                        FontAwesomeIcons.squarePollVertical,
                        color: Colors.black.withOpacity(0.3),
                      ),
                    )),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.25,
                    alignment: Alignment.center,
                    child: IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        FontAwesomeIcons.user,
                        color: Colors.black,
                      ),
                    ))
              ],
            ),
          )
        ],
      ),
    ));
  }
}
