// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_interpolation_to_compose_strings

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:my_app/main.dart';
import 'package:my_app/secondepage.dart';
import 'package:http/http.dart' as http;

class Signup extends StatefulWidget {
  const Signup({super.key});
  @override
  State<Signup> createState() => Signupstate();
}

// This widget is the root of your application.
class Signupstate extends State<Signup> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const MyHomePage(title: 'My First Flutter application'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int counter = 0;
  int current_page = 0;
  String enteredText = "";
  String message_validation = "";
  String name = "";
  String familyname = "";
  int api = 0;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController password = new TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController secpassword = new TextEditingController();
  void increment() {
    setState(() {
      counter++;
    });
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    nameController.dispose();
    password.dispose();
    email.dispose();
    secpassword.dispose();
    super.dispose();
  }

  void decrement() {
    setState(() {
      counter = 0;
    });
  }

  getdatafromapi() async {
    String url = "http://localhost:8080/users/signup?name=" +
        nameController.text +
        "&email=" +
        email.text +
        "&password=" +
        password.text;
    http.Response res = await http.post(Uri.parse(url));
    if (res.statusCode == 200) {
      setState(() {
        api = res.statusCode;
      });
    } else {
      setState(() {
        api = res.statusCode;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Title(
                color: Colors.black,
                child: Container(
                    child: Stack(
                  children: [
                    Opacity(
                      opacity: 0.5,
                      child: ClipPath(
                        clipper: WaveClipper(),
                        child: Container(
                          decoration: const BoxDecoration(
                              gradient: LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [
                              Color.fromARGB(255, 59, 0, 61),
                              Color.fromARGB(255, 234, 76, 137),
                            ],
                          )),
                          height: 700,
                        ),
                      ),
                    ),
                    ClipPath(
                      clipper: WaveClipper(),
                      child: Container(
                        /* color: Color.fromARGB(255, 147, 112, 219), */
                        height: 680,
                        padding: const EdgeInsets.only(top: 40),
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: [
                            Color.fromARGB(255, 59, 0, 61),
                            Color.fromARGB(255, 234, 76, 137),
                          ],
                        )),
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(bottom: 10),
                              child: const Text(
                                "Signup",
                                style: TextStyle(
                                    fontSize: 50,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Roboto-bold'),
                              ),
                            ),
                            if (api == 400)
                              Text(
                                message_validation,
                                style: const TextStyle(
                                    color: Colors.red,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Roboto-bold'),
                              ),
                            if (api == 200)
                              Text(
                                message_validation,
                                style: const TextStyle(
                                    color: Colors.green,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Roboto-bold'),
                              ),
                            Container(
                              margin: const EdgeInsets.only(
                                  right: 50, left: 50, top: 20, bottom: 20),
                              child: TextField(
                                  style: const TextStyle(fontFamily: 'Roboto'),
                                  textAlign: TextAlign.center,
                                  controller: nameController,
                                  decoration: InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      hintText: 'Name',
                                      prefixIcon: const Visibility(
                                        visible: true,
                                        child: Icon(
                                          Icons.person_2,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(20.0)),
                                      // ignore: prefer_const_constructors
                                      hintStyle: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'Roboto'))),
                            ),
                            Container(
                              margin: const EdgeInsets.only(
                                  right: 50, left: 50, top: 20, bottom: 20),
                              child: TextField(
                                style: const TextStyle(fontFamily: 'Roboto'),
                                textAlign: TextAlign.center,
                                controller: email,
                                decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Email',
                                    prefixIcon: const Visibility(
                                      visible: true,
                                      child: Icon(
                                        Icons.email,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(20.0)),
                                    // ignore: prefer_const_constructors
                                    hintStyle: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Roboto',
                                    )),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(
                                  right: 50, left: 50, top: 20, bottom: 20),
                              child: TextField(
                                style: const TextStyle(fontFamily: 'Roboto'),
                                textAlign: TextAlign.center,
                                controller: password,
                                decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Password',
                                    prefixIcon: const Visibility(
                                      visible: true,
                                      child: Icon(
                                        Icons.lock,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(20.0)),
                                    // ignore: prefer_const_constructors
                                    hintStyle: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Roboto',
                                    )),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(
                                  right: 50, left: 50, top: 20, bottom: 20),
                              child: TextField(
                                style: const TextStyle(fontFamily: 'Roboto'),
                                textAlign: TextAlign.center,
                                controller: secpassword,
                                decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Repeat Password',
                                    prefixIcon: const Visibility(
                                      visible: true,
                                      child: Icon(
                                        Icons.lock,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(20.0)),
                                    // ignore: prefer_const_constructors
                                    hintStyle: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Roboto',
                                    )),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(
                                      right: 20, left: 20, top: 20, bottom: 20),
                                  child: SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width - 100,
                                    height: 50,
                                    child: FilledButton(
                                        onPressed: () async {
                                          setState(() {
                                            api = 10;
                                          });
                                          await getdatafromapi();
                                          print(api);
                                          setState(() {
                                            if (api == 200) {
                                              message_validation =
                                                  "signup succesufuly!";
                                            } else {
                                              message_validation =
                                                  "Wrong email or password!";
                                            }
                                            /* if (api == 200) {
                                              Navigator.of(context).push(
                                                MaterialPageRoute(builder:
                                                    (BuildContext context) {
                                                  return Secondepage(
                                                    title: 'Home',
                                                    name: name,
                                                    familyname: familyname,
                                                  );
                                                }),
                                              );
                                            } */
                                          });
                                        },
                                        style: FilledButton.styleFrom(
                                            backgroundColor:
                                                Color.fromARGB(255, 59, 0, 61)
                                                    .withOpacity(0.8)),
                                        child: const Text(
                                          "Signup",
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontFamily: 'Roboto'),
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ))),
            /* Text(
              message_validation,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ), */
            if (api == 10)
              const CircularProgressIndicator(
                color: Color.fromARGB(255, 59, 0, 61),
              ),
            Container(
                margin: const EdgeInsets.only(
                    top: 10, bottom: 20, left: 20, right: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (BuildContext context) {
                              return Login();
                            }),
                          );
                        },
                        child: Row(
                          children: [
                            Text(
                              "Sign in ",
                              style: TextStyle(
                                fontFamily: 'Roboto-bold',
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 59, 0, 61)
                                    .withOpacity(0.8),
                              ),
                            ),
                            Icon(
                              FontAwesomeIcons.rightToBracket,
                              color: Color.fromARGB(255, 59, 0, 61)
                                  .withOpacity(0.8),
                            )
                          ],
                        ))
                  ],
                )),
          ],
        ),
      ),
    );
  }
}

class WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    debugPrint(size.width.toString());
    var path = new Path();
    path.lineTo(0, size.height);
    var firstStart = Offset(size.width / 5, size.height);
    var firstEnd = Offset(size.width / 2.25, size.height - 50.0);
    path.quadraticBezierTo(
        firstStart.dx, firstStart.dy, firstEnd.dx, firstEnd.dy);
    var secondStart =
        Offset(size.width - (size.width / 3.24), size.height - 105);
    var secondEnd = Offset(size.width, size.height - 10);
    path.quadraticBezierTo(
        secondStart.dx, secondStart.dy, secondEnd.dx, secondEnd.dy);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return true;
  }
}
